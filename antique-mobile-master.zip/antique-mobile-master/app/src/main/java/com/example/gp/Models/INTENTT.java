package com.example.gp.Models;

public interface INTENTT {
    public void OnitemClicked1(int Id);
}
