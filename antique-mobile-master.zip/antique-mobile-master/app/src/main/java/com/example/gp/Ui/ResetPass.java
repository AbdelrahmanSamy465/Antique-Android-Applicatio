package com.example.gp.Ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.gp.R;

public class ResetPass extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_pass);
    }
}