package com.example.gp.Models;

public class Mymodel {
    int image;

    public Mymodel(int image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
