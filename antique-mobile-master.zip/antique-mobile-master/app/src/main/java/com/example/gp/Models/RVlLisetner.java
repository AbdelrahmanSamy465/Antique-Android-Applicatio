package com.example.gp.Models;

public interface RVlLisetner {
    public void OnitemClicked(int id);
}

